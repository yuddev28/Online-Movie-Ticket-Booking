package model;

public enum TicketStatus {
	PAID,
	UNPAID,
	CANCELLED
}
