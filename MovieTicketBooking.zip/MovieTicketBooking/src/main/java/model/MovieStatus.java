package model;

public enum MovieStatus {
	COMING_SOON,
	NOW_SHOWING,
	STOPPED_SHOWING
}
