package model;

public enum PaymentMethod {
	CASH,
	ONLINE
}
