package model;

public enum Role {
	ADMIN,
	USER
}